with open("tipos_Parqueaderos.json") as f:
    pisos = json.load(f)
    print(pisos["Piso1"])

def archivo_pisos():

    # aqui va a ir la funcion donde se va a mostrar los pisos correspondientes que el ususario va a digitar
    placa = str(input("Ingrese su número de placa:\n"))
    placa.upper()

    despiso= eval(input("A que piso quiere dirijirse:\n"))

    if despiso==1:
       print(pisos["Piso1"])

    elif despiso == 2:
        print(pisos["Piso2"])
    elif despiso == 3:
        print(pisos["Piso3"])

    elif despiso == 4:
        print(pisos["Piso4"])

    elif despiso == 5:
        print(pisos["Piso5"])

    elif despiso == 6:
        print(pisos["Piso6"])
    else:
        print("El dato que ingresó no existe :)")