


tipo_usuario=['Estudiante', 'Personal Adminstrativo' ,'Profesores']


def tipousuario():
    print(" Que tipo de usuario es: \n 1) ESTUDIANTE \n 2) PERSONAL ADMINISTRATIVO \n  3) PROFESOR \n")
    # Leemos lo que ingresa el usuario
    eligio = input()
    if eligio == "1":
        return tipo_usuario[0]
    elif eligio == "2":
        return tipo_usuario[1]
    elif eligio == "3":
        return tipo_usuario[2]
    else:
        print("Opción no válida")