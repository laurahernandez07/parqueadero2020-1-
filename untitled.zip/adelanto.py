#titulo: parqueadero.py
#descripcio: sistema de administracion de parqueo desarrollado en el lenguaje de programacion python para la universidad PUJ
#Autores: Camila Peñafiel Viafara y Laura Hernández Quiroz
#version de python : 3.8
#===========================================================================================================================
import json
import math

vehiculos=["Automóvil","Automóvil Eléctrico","Motocicleta","Discapacitado"]
tipousuario=["Estudiante","Profesor","Personal Administrativo","Visitantes"]
tipopago=["Diario","Mensualidad"]

#función para leer un archivo json
def leerjson(nombreArchivo):
    archivo=open(nombreArchivo,"r",encoding="utf-8")
    dic=json.load(archivo)
    archivo.close()
    return dic


#Las funciones tipo_vehiculo , tipo_plan y tipo_usuario son para tener acceso a la información que
#el usuario ingrese y no existan errores de ortografía
def tipo_vehiculo():
    print("Ingrese su tipo de vehiculo\n 1. Automóvil\n 2.Automóvil Eléctrico\n 3.Motocicleta\n 4.Discapacitado")
    eligio=str(input())
    if eligio=="1":
        return vehiculos[0]
    elif eligio=="2":
        return vehiculos[1]
    elif eligio=="3":
        return vehiculos[2]
    elif eligio=="4":
        return vehiculos[3]
    else:
        print("OPCIÓN NO VALIDA ")
def tipo_plan():
    print("Ingrese su tipo de pago:\n 1.Diario\n 2.Mensualidad\n")
    eligio=str(input())
    if eligio=="1":
        return tipopago[0]
    elif eligio=="2":
        return tipopago[1]
    else:
        print("OPCIÓN NO VALIDA")
def tipo_usuario():
    print("Ingrese que tipo de usuario es:\n 1.Estudiante\n 2.Profesor\n 3.Personal Administrativo\n")
    eligio=str(input())
    if eligio=="1":
        return tipousuario[0]
    elif eligio=="2":
        return tipousuario[1]
    elif eligio=="3":
        return tipousuario[2]
    else:
        print("OPCIÓN NO VALIDA")

#Función que permite verificar si el usuario está registrando más de dos vehiculos al sistema
def registro_vehiculos(usuariosPUJ,baseDatos,identificación,placaRegistro):
    flag=""
    tam=len(usuariosPUJ)
    indice=0
    while indice < tam:
        if usuariosPUJ[indice][1]== identificación:
            flag=True
            print("Lo sentimos " + str(usuariosPUJ[indice][0]) + ",Usted ya se encuentra registrado en el sistema con número de identificación " + str(
                usuariosPUJ[indice][1]) + " tipo de vehículo " + str(usuariosPUJ[indice][4]) + " con placa " + str(usuariosPUJ[indice][3]))
            return usuariosPUJ
            break

        indice+=1
    if flag!= True:
        usuariosPUJ.append(baseDatos)
        print("Usted registro su vehiculo exitosamente ")
        return usuariosPUJ

#Función que permite el ingreso de usuarios al sistema del parqueadero y verifica si la placa que
#ingresó existe en el sistema, si no existe, se le pide que ingrese los datos y se añadiría al
#sistema como tipo persona: VISITANTES y como  tipo de pago: DIARIO.
def verificar_Placa (usuariosPUJ,placaIngreso):
    flag=""
    for users in range(len(usuariosPUJ)):
        if placaIngreso==usuariosPUJ [users][3]:
            flag= True
            print("BIENVENIDO " + str(usuariosPUJ[users][0]) + "\nla placa " + str(
                placaIngreso) + " ya se encuentra registrada en el sistema\nUsted es " + str(
                usuariosPUJ[users][2]) + " de la Pontificia Universidad Javeriana Cali")
            return usuariosPUJ
            break
    if flag != True:
        print("Lo sentimos, tu placa no está registrada,completa los siguientes datos\n")
        nombreUsuario=str(input("Ingrese su nombre completo"))
        identificacion=eval(input("Ingrese su numero de identificación"))
        tipoVehiculo= tipo_vehiculo()
        newUser= [nombreUsuario, identificacion, "Visitante", placaIngreso, tipoVehiculo, "Diario"]
        usuariosPUJ.append(newUser)
        return usuariosPUJ

#función que crea la matriz de inicio, indicando las posiciones disponibles con la "O".
def crear_matrizDisponibilidad():
    disponibilidadPisos={}
    for x in range(1,6):
        disponibilidadPisos["Piso"+ str(x)]=[]
        for y in range(10):
            puesto=[]
            for j in range(10):
                puesto.append("O")
            disponibilidadPisos[ "Piso"+ str(x)].append(puesto)

    disponibilidadPisos["Piso6"]=[0]
    for y in range(1,6):
        puesto=[]
        for r in range(10):
            puesto.append("O")
        disponibilidadPisos["Piso6"].append(puesto)
    return disponibilidadPisos

#función que permite verificar si el espacio seleccionado por el usuarios es compatible
#con el tipo de vehiculo que posee.
def espacioEstacionamiento(tipoVehiculo):
    print("tipo Vehiculo", tipoVehiculo)
    listaTypes = ["Automóvil","Motocicleta"]
    listaEspacio=[1,3]
    for x in range(len(listaTypes)):
        if listaTypes[x]== tipoVehiculo:
            numEspacio=listaEspacio[x]
            return numEspacio


#funcón que muestra el piso que el usuario ingresó para parquear su vehiculo,pide el lugar donde quiere parquear
# y en esa posición cambia la disponibilidad del puesto a "X" (ocupado).
def estacionar_Vehiculo(usuariosPUJ, placa, disponiblePisos, pisos, pisoDeseado):
    listaPisos = []
    for piso in pisos:
        listaPisos.append(piso)

    for x in range(1, len(listaPisos) + 1):
        if pisoDeseado == x:
            pisoDeseado = listaPisos[x - 1]

    for muestraPiso in disponiblePisos:
        if muestraPiso == pisoDeseado:
            print("*****" + str(muestraPiso) + "*****")
            for w in disponiblePisos[muestraPiso]:
                print(w)
            print("********************")
            break

    posicionFila = eval(input("Digite la fila donde desea estacionar su vehículo:\n"))
    posicionColumna = eval(input("Digite la columna donde desea posicionar su vehículo:\n"))

    for y in range(len(usuariosPUJ)):
        if usuariosPUJ[y][3] == placa:
            tipoVehiculo = usuariosPUJ[y][4]
            break

    matrizExcep = [["Automóvil Eléctrico", [1, 2]], ["Discapacitado", [1, 4]]]

    flag = ""
    for i in range(1, len(disponiblePisos[muestraPiso]) + 1):  # FILA
        if i == posicionFila:

            for j in range(1, len(disponiblePisos[muestraPiso][i - 1]) + 1):  # COLUMNA
                ubicacion = disponiblePisos[muestraPiso][i - 1][j - 1]
                if j == posicionColumna:
                    if ubicacion == ("O"):

                        flag = True
                        tipoPosicion = pisos[muestraPiso][i - 1][j - 1]
                        point = ""

                        indice = 0
                        tam = len(matrizExcep)
                        while indice < tam:
                            if matrizExcep[indice][0] == tipoVehiculo:
                                point = True
                                for w in range(len(matrizExcep[indice][1])):
                                    num = matrizExcep[indice][1][w]
                                    if num == tipoPosicion:
                                        disponiblePisos[muestraPiso][i - 1].remove(ubicacion)
                                        acceso = "X"
                                        disponiblePisos[muestraPiso][i - 1].insert(j - 1, acceso)
                                        print("El vehiculo ha ingresado al parqueadero")
                                        vehiParqueados[placa] = [muestraPiso, posicionColumna, posicionFila]
                                        return main(disponiblePisos,vehiParqueados)
                                        break
                            indice+=1

                        if point != True:
                            if tipoPosicion == espacioEstacionamiento(tipoVehiculo):
                                disponiblePisos[muestraPiso][i - 1].remove(ubicacion)
                                acceso = "X"
                                disponiblePisos[muestraPiso][i - 1].insert(j - 1, acceso)
                                print("El vehiculo ha ingresado al parqueadero")
                                vehiParqueados[placa] = [muestraPiso, posicionColumna, posicionFila]
                                return main(disponiblePisos,vehiParqueados)
                                break
                            else:
                                print("El parqueadero seleccionado no coincide con el tipo de tu vehiculo, vuelve a intentarlo")
                                return estacionar_Vehiculo(usuariosPUJ,placa,disponiblePisos,pisos,pisoDeseado)

    if flag != True:
        print("La plaza donde quiere parquear no se encuentra disponible, por intentelo nuevamente.")
        return estacionar_Vehiculo(usuariosPUJ, placa, disponiblePisos, pisos, pisoDeseado)



def placas():
    pI = input("Digite la placa de su vehículo:\n")
    placaIngreso = pI.upper()
    return placaIngreso



# permite el cobro al retirarlo del parqueadero:se teniene en cuenta la placa con la que ingresó
#los minutos que estuvo en el parqueadero,el plan de pago (diario o mensualidad). Si el plan de pago es mensualidad no se
# ejecuta el cobro y si el plan de pago es diario se hace el cobro respectivo dependiendo el tipo de usuario con el que está registrado
def cobro_Retiro(usuariosPUJ,placaRetiro,vehiParket,parqueo):

    flag = ""
    for placa in vehiParket.keys():
        if placa == placaRetiro:
            print("Usted se encuentra saliendo de la PUJ ")
            for x in range(len(usuariosPUJ)):
                if usuariosPUJ[x][5] == tipopago[1]:
                    flag = True
                    print("Gracias por la visita,puede continuar.\n")
                    break

    if flag != True:
        minutos = eval(input("Ingrese los minutos que ha permanecido en la PUJ\n"))
        for y in range(len(usuariosPUJ)):
            if usuariosPUJ[y][2] == tipousuario[0]:
                x = (minutos / 60)
                res = math.ceil(x)
                totalapagar = res * 1000

            elif usuariosPUJ[y][2] == tipousuario[1]:
                x = (minutos / 60)
                res = math.ceil(x)
                totalapagar = res * 2000

            elif usuariosPUJ[y][2] == tipousuario[2]:
                x = (minutos / 60)
                res = math.ceil(x)
                totalapagar = res * 1500

            elif usuariosPUJ[y][2] == tipousuario[3]:
                x = (minutos / 60)
                res = math.ceil(x)
                totalapagar = res * 3000

    print("El total a pagar es de", totalapagar, "pesos")
    return totalapagar


    pisoEligido = vehiParket[placaRetiro][0]    #Recorrer placaRetiro == llave
    columnaEligida = vehiParket[placaRetiro][1]
    for floor in range(len(parqueo[pisoEligido])):
        if parqueo[pisoEligido][floor][columnaEligida]=="X":
            parqueo[pisoEligido][floor][columnaEligida] = "O"
            return parqueo

#funcion que saca la placa
def buscar_usuario(usuariosPUJ, placa):
    for i in usuariosPUJ:
        if i[3] == placa:
            return i

#función que crea el reporte de los vehiculos
def crear_reporte(usuariosPUJ, vehiculosParqueados):
    vehiculosEstacionadosEstudiantes = 0
    vehiculosEstacionadosPersonal = 0
    vehiculosEstacionadosVisitantes = 0
    vehiculosEstacionadosProfesor = 0

    for placa, lista in vehiParqueados.items():
        usuario = buscar_usuario(usuariosPUJ, placa)
        if usuario[2] == "Estudiante":
            vehiculosEstacionadosEstudiantes = vehiculosEstacionadosEstudiantes + 1
        elif usuario[2] == "Personal Administrativo":
            vehiculosEstacionadosPersonal = vehiculosEstacionadosPersonal + 1
        elif usuario[2] == "Visitantes":
            vehiculosEstacionadosVisitantes = vehiculosEstacionadosVisitantes + 1
        elif usuario[2] == "Profesor":
            vehiculosEstacionadosProfesor = vehiculosEstacionadosProfesor + 1

    automovilesParqueados = 0
    electricosParqueados = 0
    motocicletasParqueadas = 0
    discapacitadosParqueados = 0

    for placa, lista in vehiParqueados.items():
        usuario = buscar_usuario(usuariosPUJ, placa)
        if usuario[4] == "Automóvil":
            automovilesParqueados = automovilesParqueados + 1
        elif usuario[4] == "Automóvil Eléctrico":
            electricosParqueados = electricosParqueados + 1
        elif usuario[4] == "Motocicleta":
            motocicletasParqueadas = motocicletasParqueadas + 1
        elif usuario[4] == "Discapacitado":
            discapacitadosParqueados = discapacitadosParqueados + 1

    print("Vehiculos estacionados por estudiantes: " + str(vehiculosEstacionadosEstudiantes))
    print("Vehiculos estacionados por el personal: " + str(vehiculosEstacionadosPersonal))
    print("Vehiculos estacionados por profesores: " + str(vehiculosEstacionadosProfesor))
    print("Vehiculos estacionados por visitantes: " + str(vehiculosEstacionadosVisitantes))
    print("***************************************")
    print("Automoviles estacionados: ", str(automovilesParqueados))
    print("Automoviles electricos estacionados: ", str(electricosParqueados))
    print("Motociclestas estacionados: ", str(motocicletasParqueadas))
    print("Discapacitados estacionados: ", str(discapacitadosParqueados) + "\n")


#Función menú que permite al usuario esocger la opción que desee
def main(matrizPisos,vehiParqueados):
    if matrizPisos == {}:
        matrizPisos = crear_matrizDisponibilidad()

    users = leerjson("usuarios.json")

    cicloMenu = 0
    while (cicloMenu < 1):

        data = users["usuarios"]

        print("-----------BIENVENIDO A LA PONTIFICIA UNIVERSIDAD JAVERIANA CALI---------")
        print("1. Registro Parquedero")
        print("2. Ingresar Parqueadero")
        print("3. Mostrar espacios de parqueadero")
        #print("4. Mostrar vehiculos parqueados ")
        print("4. Retirar Parqueadero")
        print("5. Crear reporte")
        print("6. Salir")

        opcion = int(input("Digite su opcion: "))

        if opcion == 1:
            baseDatos = []
            nombreCompleto = str(input("Ingrese su nombre completo:\n"))
            identificacion = eval(input("Ingrese su número de identificación:\n"))
            usuarios = tipo_usuario()
            pR = str(input("Ingrese el número de placa de su vehículo:\n"))
            placaRegistro = pR.upper()
            print(placaRegistro)
            tipoVehiculo = tipo_vehiculo()
            print(tipoVehiculo)
            plan = tipo_plan()

            baseDatos.append(nombreCompleto)
            baseDatos.append(identificacion)
            baseDatos.append(usuarios)
            baseDatos.append(placaRegistro)
            baseDatos.append(tipoVehiculo)
            baseDatos.append(plan)

            adicionar_Vehiculo = registro_vehiculos(data, baseDatos, identificacion, placaRegistro)

            #print("*****USUARIOS*****")

            #for i in adicionar_Vehiculo:
                #print(i)
            #print("********************")

        elif opcion == 2:
            pR = input("Digite la placa de su vehículo para el ingreso al parqueadero:\n")
            placaIngreso= pR.upper()
            entrada_Parqueadero = verificar_Placa(data, placaIngreso)
            #print("*****INGRESO DE USUARIOS AL PARQUEADERO*****")
            #for j in entrada_Parqueadero:
                #print(j)
            #print("********************")

            tiposParquederos = leerjson("tipos_Parqueaderos.json")
            pisoDeseado = eval(input("Diga que piso desea estacionar su vehículo:\n1. Piso1\n2. Piso2\n3. Piso3\n4. Piso4\n5. Piso5\n6. Piso6\nUsted escoge el Piso "))

            matrizPisos = estacionar_Vehiculo(entrada_Parqueadero, placaIngreso, matrizPisos, tiposParquederos,pisoDeseado)

        elif opcion == 3:
            for piso, parqueaderos in matrizPisos.items():
                print("*****" + str(piso) + "*****")
                for i in parqueaderos:
                    print(i)
            break

        #elif opcion == 4:
            #print(vehiParqueados)

        elif opcion == 4:
            p = str(input("Ingrese la placa de su vehículo:\n"))
            placaRetiro = p.upper
            matrizPisos = cobro_Retiro(data, placaRetiro, vehiParqueados, matrizPisos)  # diccionario sebas ingreso

        elif opcion == 5:
            crear_reporte(data, vehiParqueados)

        else:
            break



users = leerjson("usuarios.json")
vehiParqueados={}
matrizPisos = {}

main(matrizPisos,vehiParqueados)

