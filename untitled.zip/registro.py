def registro_vehiculos(usuarios):
    nombre = str(input("Ingrese su Nombre completo: \n"))
    apellido = str(input("Ingrese sus Apellidos: \n "))
    nombresapellido= nombre + " " + apellido
    ID = int(input("Ingrese su numero de identificación: \n "))
    duplicados:(ID, usuarios)
    tipodeusuario = str(input("Tipo de usuario: \n "))
    placa = str(input("Ingrese el numero de placa: \n  "))
    verificarparqueaderos(archivo_pisos())
    tipovehiculo = tipo_vehiculo()
    plandepago = tipo_plan()
    aux.append([nombresapellido,ID,tipodeusuario,placa,tipodeusuario,plandepago])
    usuarios["usuarios"] +=aux
    with open ("usuarios.json","w") as file:
        json.dump(usuarios,file,indent=1)
